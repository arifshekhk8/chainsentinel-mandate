# Mandate transaction logs

Team ChainSentinel. International Track Topic F. Prepared 20 October 2026.

Start with transaction-register.csv or transaction-register.json. They list all 13 original Sepolia hashes in block order. All preparedAtUTC fields mean saved preparation time, not inclusion time. Status 0 is the original reverted deposit; status 1 means successful receipt. The zero-transaction safety checks are eth_call simulations and are not counted as mined transactions.

receipt-index.json maps each hash to an original file and JSON Pointer. Eleven have detailed saved receipt/log payloads. The two deployment receipts are original export summaries. A fresh read-only lookup returned HTTP 403; its retrieval record is included without claiming success. Never interpret missing details as a new verification.

The evidence/ and demo/ trees preserve original file bytes and paths. Historical embedded paths can be resolved through evidence/locations.json. Source paths named in freeze manifests refer to the separate source deliverable; source code is not part of this log archive. Earlier immutable records can contain pending flags or CLI extension-test defaults; use the later export/revocation/access verifications for the final checkpoint.

Public evidence is on Sepolia 11155111. The v5 model run uses independent local 31337 resets, 40 fixed cases and 27 local payment receipts. N13 and prior-repair limits remain in the saved analysis. Hosting checks are separate and do not add payments or cases. The three public live requests and their request-to-plan-to-payment references remain in the original export.

manifest.json gives each entry’s size and SHA-256, and identifies unchanged original files. SHA256SUMS.txt covers all entries except itself. In a shell inside the extracted folder, run shasum -a 256 -c SHA256SUMS.txt. Compare the manifest with the original repository files when available. The manifest is navigation/integrity evidence, not a cryptographic claim of authorship or security.

No key, environment file, database, private registration material, installed dependency or workspace password belongs in this archive. Reviewer access and source handover are delivered separately. No new payment, model evaluation, email or publication was performed to prepare it.
